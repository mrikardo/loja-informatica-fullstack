import React, { useState } from "react";

export default function OrderTracking() {
  const [codigo, setCodigo] = useState("");
  const [resultado, setResultado] = useState(null);

  const rastrear = async () => {
    const res = await fetch(`http://localhost:3000/api/orders/${codigo}`);
    const data = await res.json();
    setResultado(data);
  };

  return (
    <div style={{ padding: 20 }}>
      <h1>Rastrear Pedido</h1>
      <input
        placeholder="Digite o código de rastreio"
        value={codigo}
        onChange={(e) => setCodigo(e.target.value)}
        style={{ width: "100%", marginBottom: 10, padding: 8 }}
      />
      <button onClick={rastrear} style={{ padding: 10 }}>
        Rastrear
      </button>
      {resultado && (
        <pre style={{ backgroundColor: "#eee", padding: 10, marginTop: 10 }}>
          {JSON.stringify(resultado, null, 2)}
        </pre>
      )}
    </div>
  );
}