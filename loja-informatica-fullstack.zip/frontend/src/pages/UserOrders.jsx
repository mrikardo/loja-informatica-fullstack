import React, { useEffect, useState, useContext } from "react";
import { AuthContext } from "../context/AuthContext";

export default function UserOrders() {
  const { token } = useContext(AuthContext);
  const [orders, setOrders] = useState([]);

  useEffect(() => {
    fetch("http://localhost:3000/api/orders", {
      headers: { Authorization: `Bearer ${token}` },
    })
      .then((res) => res.json())
      .then(setOrders);
  }, [token]);

  return (
    <div style={{ padding: 20 }}>
      <h1>Meus Pedidos</h1>
      <ul>
        {orders.map((order, i) => (
          <li key={i}>
            Pedido #{order._id} - {order.products.map((p) => p.name).join(", ")} - R${" "}
            {order.total.toFixed(2)} - {order.status}
          </li>
        ))}
      </ul>
    </div>
  );
}