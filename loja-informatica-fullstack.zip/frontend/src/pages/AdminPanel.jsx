import React, { useState, useEffect, useContext } from "react";
import { AuthContext } from "../context/AuthContext";
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer } from "recharts";

export default function AdminPanel() {
  const { token } = useContext(AuthContext);
  const [pedidos, setPedidos] = useState([]);

  useEffect(() => {
    fetch("http://localhost:3000/api/orders", {
      headers: { Authorization: `Bearer ${token}` },
    })
      .then((res) => res.json())
      .then(setPedidos);
  }, [token]);

  const resumo = pedidos.reduce((acc, pedido) => {
    const dia = new Date(pedido.createdAt).toLocaleDateString();
    acc[dia] = (acc[dia] || 0) + pedido.total;
    return acc;
  }, {});

  const data = Object.entries(resumo).map(([name, total]) => ({ name, total }));

  return (
    <div className="p-4">
      <h1>Painel Administrativo</h1>

      <h2>Gráfico de Vendas</h2>
      <ResponsiveContainer width="100%" height={300}>
        <BarChart data={data}>
          <XAxis dataKey="name" />
          <YAxis />
          <Tooltip />
          <Bar dataKey="total" fill="#3b82f6" />
        </BarChart>
      </ResponsiveContainer>

      <h2>Pedidos Recentes</h2>
      <ul>
        {pedidos.map((p, i) => (
          <li key={i}>
            Pedido #{p._id} - R$ {p.total.toFixed(2)} - {p.status}
          </li>
        ))}
      </ul>
    </div>
  );
}