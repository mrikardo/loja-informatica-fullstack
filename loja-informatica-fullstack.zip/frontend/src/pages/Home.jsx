import React, { useEffect, useState, useContext } from "react";
import { AuthContext } from "../context/AuthContext";

export default function Home() {
  const [produtos, setProdutos] = useState([]);
  const { token } = useContext(AuthContext);

  useEffect(() => {
    fetch("http://localhost:3000/api/products")
      .then((res) => res.json())
      .then(setProdutos);
  }, []);

  const comprar = async (produto) => {
    if (!token) return alert("Faça login para comprar");

    const res = await fetch("http://localhost:3000/api/orders", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${token}`,
      },
      body: JSON.stringify({
        products: [produto],
        total: produto.price,
      }),
    });
    const data = await res.json();
    alert("Pedido realizado!");
  };

  return (
    <div className="p-4 grid gap-4">
      {produtos.map((produto, i) => (
        <div key={i} style={{ border: "1px solid #ccc", padding: 10, borderRadius: 6 }}>
          <h2>{produto.name}</h2>
          <p>R$ {produto.price.toFixed(2)}</p>
          <button onClick={() => comprar(produto)}>Comprar</button>
        </div>
      ))}
    </div>
  );
}