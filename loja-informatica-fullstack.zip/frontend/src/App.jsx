import React, { useState, useEffect } from "react";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import Home from "./pages/Home";
import AdminPanel from "./pages/AdminPanel";
import OrderTracking from "./pages/OrderTracking";
import Login from "./pages/Login";
import UserOrders from "./pages/UserOrders";
import { AuthContext } from "./context/AuthContext";

export default function App() {
  const [token, setToken] = useState(localStorage.getItem("token") || null);

  useEffect(() => {
    if (token) localStorage.setItem("token", token);
  }, [token]);

  return (
    <AuthContext.Provider value={{ token, setToken }}>
      <Router>
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/admin" element={<AdminPanel />} />
          <Route path="/rastreio" element={<OrderTracking />} />
          <Route path="/login" element={<Login />} />
          <Route path="/meus-pedidos" element={<UserOrders />} />
        </Routes>
      </Router>
    </AuthContext.Provider>
  );
}