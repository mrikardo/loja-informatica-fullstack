const express = require('express');
const Order = require('../models/Order');
const jwt = require('jsonwebtoken');
const router = express.Router();

function verifyToken(req, res, next) {
  const token = req.headers.authorization;
  if (!token) return res.status(403).json({ error: 'Token não fornecido' });
  try {
    const decoded = jwt.verify(token.split(' ')[1], process.env.JWT_SECRET);
    req.user = decoded;
    next();
  } catch {
    res.status(401).json({ error: 'Token inválido' });
  }
}

router.post('/', verifyToken, async (req, res) => {
  const { products, total } = req.body;
  const order = new Order({ userId: req.user.id, products, total });
  await order.save();
  res.json({ message: 'Pedido criado' });
});

router.get('/', verifyToken, async (req, res) => {
  const orders = req.user.isAdmin ? await Order.find() : await Order.find({ userId: req.user.id });
  res.json(orders);
});

module.exports = router;